<?php
namespace Database\Seeders;

use App\Models\Customer;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $customers = [
            ['full_name' => 'S.Coups', 'email' => 'scoups@example.com', 'phone' => '+63 917 123 4567', 'joined' => '2026-01-12', 'orders' => 24, 'spent' => 48650.0, 'status' => 'Active'],
            ['full_name' => 'Jeonghan', 'email' => 'jeonghan@example.com', 'phone' => '+63 918 234 5678', 'joined' => '2026-02-03', 'orders' => 18, 'spent' => 32780.5, 'status' => 'Active'],
            ['full_name' => 'Joshua', 'email' => 'joshua@example.com', 'phone' => '+63 919 345 6789', 'joined' => '2026-03-18', 'orders' => 31, 'spent' => 61420.75, 'status' => 'Active'],
            ['full_name' => 'Jun', 'email' => 'jun@example.com', 'phone' => '+63 920 456 7890', 'joined' => '2026-04-09', 'orders' => 9, 'spent' => 12990.0, 'status' => 'Inactive'],
            ['full_name' => 'Hoshi', 'email' => 'hoshi@example.com', 'phone' => '+63 921 567 8901', 'joined' => '2026-05-27', 'orders' => 15, 'spent' => 27435.25, 'status' => 'Active'],
            ['full_name' => 'Wonwoo', 'email' => 'wonwoo@example.com', 'phone' => '+63 922 678 9012', 'joined' => '2026-06-14', 'orders' => 12, 'spent' => 19860.0, 'status' => 'Active'],
            ['full_name' => 'Woozi', 'email' => 'woozi@example.com', 'phone' => '+63 923 789 0123', 'joined' => '2026-07-08', 'orders' => 20, 'spent' => 35990.5, 'status' => 'Active'],
            ['full_name' => 'DK', 'email' => 'dk@example.com', 'phone' => '+63 924 890 1234', 'joined' => '2026-08-21', 'orders' => 7, 'spent' => 10680.0, 'status' => 'Inactive'],
            ['full_name' => 'Mingyu', 'email' => 'mingyu@example.com', 'phone' => '+63 925 901 2345', 'joined' => '2026-09-02', 'orders' => 26, 'spent' => 50120.0, 'status' => 'Active'],
            ['full_name' => 'The8', 'email' => 'the8@example.com', 'phone' => '+63 926 012 3456', 'joined' => '2026-09-16', 'orders' => 19, 'spent' => 38740.0, 'status' => 'Active'],
            ['full_name' => 'Seungkwan', 'email' => 'seungkwan@example.com', 'phone' => '+63 927 123 4567', 'joined' => '2026-10-01', 'orders' => 25, 'spent' => 48950.0, 'status' => 'Active'],
            ['full_name' => 'Vernon', 'email' => 'vernon@example.com', 'phone' => '+63 928 234 5678', 'joined' => '2026-10-11', 'orders' => 20, 'spent' => 40100.0, 'status' => 'Active'],
            ['full_name' => 'Dino', 'email' => 'dino@example.com', 'phone' => '+63 929 345 6789', 'joined' => '2026-10-20', 'orders' => 17, 'spent' => 34980.0, 'status' => 'Active'],
        ];
        foreach ($customers as $customer) {
            Customer::updateOrCreate(['email' => $customer['email']], $customer);
        }

        $users = [
            ['username' => 'azea_natividad', 'full_name' => 'Azea Natividad', 'name' => 'Azea Natividad', 'email' => 'azea.natividad@laravelpos.test', 'role' => 'Administrator', 'last_active' => 'Today, 9:42 AM', 'status' => 'Active'],
            ['username' => 'enzo', 'full_name' => 'Enzo Garcia', 'name' => 'Enzo Garcia', 'email' => 'enzo@laravelpos.test', 'role' => 'Store Manager', 'last_active' => 'Today, 8:15 AM', 'status' => 'Active'],
            ['username' => 'althea', 'full_name' => 'Althea Ramos', 'name' => 'Althea Ramos', 'email' => 'althea@laravelpos.test', 'role' => 'Cashier', 'last_active' => 'Yesterday, 6:30 PM', 'status' => 'Active'],
            ['username' => 'joaquin', 'full_name' => 'Joaquin Lim', 'name' => 'Joaquin Lim', 'email' => 'joaquin@laravelpos.test', 'role' => 'Cashier', 'last_active' => 'Oct 24, 4:18 PM', 'status' => 'Active'],
            ['username' => 'bianca', 'full_name' => 'Bianca Flores', 'name' => 'Bianca Flores', 'email' => 'bianca@laravelpos.test', 'role' => 'Inventory Clerk', 'last_active' => 'Oct 22, 1:05 PM', 'status' => 'Away'],
            ['username' => 'rafael', 'full_name' => 'Rafael Dizon', 'name' => 'Rafael Dizon', 'email' => 'rafael@laravelpos.test', 'role' => 'Auditor', 'last_active' => 'Oct 18, 10:20 AM', 'status' => 'Inactive'],
        ];
        foreach ($users as $user) {
            User::updateOrCreate(
                ['email' => $user['email']],
                array_merge($user, ['password' => 'ChangeMe123!'])
            );
        }
    }
}
